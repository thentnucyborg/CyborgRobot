var annotated_dup =
[
    [ "ArDockInterface", "classArDockInterface.html", "classArDockInterface" ],
    [ "ArLocalizationTask", "classArLocalizationTask.html", "classArLocalizationTask" ],
    [ "ArServerModeDock", "classArServerModeDock.html", "classArServerModeDock" ],
    [ "ArServerModeDockLynx", "classArServerModeDockLynx.html", "classArServerModeDockLynx" ],
    [ "ArServerModeDockPatrolBot", "classArServerModeDockPatrolBot.html", "classArServerModeDockPatrolBot" ],
    [ "ArServerModeDockPatrolBotNiMH", "classArServerModeDockPatrolBotNiMH.html", "classArServerModeDockPatrolBotNiMH" ],
    [ "ArServerModeDockPioneer", "classArServerModeDockPioneer.html", "classArServerModeDockPioneer" ],
    [ "ArServerModeDockPowerBot", "classArServerModeDockPowerBot.html", "classArServerModeDockPowerBot" ],
    [ "ArServerModeDockSimulator", "classArServerModeDockSimulator.html", "classArServerModeDockSimulator" ],
    [ "ArServerModeDockTriangleBump", "classArServerModeDockTriangleBump.html", "classArServerModeDockTriangleBump" ],
    [ "ArServerModeDockTriangleBumpBackwards", "classArServerModeDockTriangleBumpBackwards.html", "classArServerModeDockTriangleBumpBackwards" ]
];