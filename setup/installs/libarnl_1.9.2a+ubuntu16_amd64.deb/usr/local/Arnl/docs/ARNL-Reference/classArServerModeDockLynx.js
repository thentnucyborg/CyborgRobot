var classArServerModeDockLynx =
[
    [ "checkDock", "classArServerModeDockLynx.html#a6707a42bcbb9b6fb6c5ae9f226424e5f", null ],
    [ "disableDock", "classArServerModeDockLynx.html#a7896fdc089368a215b638309ae370473", null ],
    [ "enableDock", "classArServerModeDockLynx.html#a890ef8ea341b1e993aa86203fe6926ea", null ],
    [ "isDocked", "classArServerModeDockLynx.html#a98e145e7e840bb81089ba07c200901e7", null ],
    [ "restoreFromDockFile", "classArServerModeDockLynx.html#ab9963b96771a5fc0d17aa5efb20eb975", null ]
];