var NAVTREE =
[
  [ "ARNL", "index.html", [
    [ "Introduction to ARNL Laser Localization", "index.html#arnlintro", null ],
    [ "Programming and Using ArLocalizationTask", "index.html#arnlproguse", null ],
    [ "Configuring ARNL Parameters", "index.html#arnlconfig", null ],
    [ "Laser Localization Results and States", "index.html#arnlresultstates", null ],
    [ "Getting Lost and the Failed Callback.", "index.html#arnlfailcallback", null ],
    [ "Making Maps for Laser Localization", "index.html#arnlmapping", null ],
    [ "Some Advanced Features of ARNL Laser Localization", "index.html#arnladvanced", null ],
    [ "ARNL Laser Localization Parameters in Detail", "index.html#arnlparameters", null ],
    [ "Classes", "annotated.html", [
      [ "Class List", "annotated.html", "annotated_dup" ],
      [ "Class Hierarchy", "hierarchy.html", "hierarchy" ],
      [ "Class Members", "functions.html", [
        [ "All", "functions.html", "functions_dup" ],
        [ "Functions", "functions_func.html", "functions_func" ],
        [ "Variables", "functions_vars.html", null ]
      ] ]
    ] ],
    [ "Examples", "examples.html", "examples" ]
  ] ]
];

var NAVTREEINDEX =
[
"annotated.html",
"classArServerModeDock.html#abb14c23a52ebc0aefc4a2ac7141ff830"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';