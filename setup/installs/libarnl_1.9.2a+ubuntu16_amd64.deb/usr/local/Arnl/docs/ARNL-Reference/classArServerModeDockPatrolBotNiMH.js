var classArServerModeDockPatrolBotNiMH =
[
    [ "isDocked", "classArServerModeDockPatrolBotNiMH.html#ae3b4df45c76113bc60205129f66e6f76", null ],
    [ "setAutoDock", "classArServerModeDockPatrolBotNiMH.html#a1fc45e80a3b77cf38db3488cd62ded9f", null ],
    [ "setNeedBalance", "classArServerModeDockPatrolBotNiMH.html#a7100ea943dddfee45eec6e32d3587079", null ],
    [ "subclassAddParamsDoneCharging", "classArServerModeDockPatrolBotNiMH.html#af2c14b58ed2f247dacc00e96352d1752", null ],
    [ "subclassDoneCharging", "classArServerModeDockPatrolBotNiMH.html#ab06a991ed39826def4b4722f4138044e", null ],
    [ "subclassGetDockInfoString", "classArServerModeDockPatrolBotNiMH.html#afd7ce80ac0fbefef40508e229ab040b0", null ],
    [ "subclassNeedsAutoDock", "classArServerModeDockPatrolBotNiMH.html#abf8299842ebe9822a147d6994c7b220e", null ],
    [ "subclassNotDoneCharging", "classArServerModeDockPatrolBotNiMH.html#a678c1b5174a72cec9a4fa85e2ef47c85", null ]
];